package dev.volcent.firstLab.task;

final public class SortingOptions {
    static final public String NoSort = "ns";
    static final public String DefaultSort = "ds";
    static final public String AlternateSort = "as";
}