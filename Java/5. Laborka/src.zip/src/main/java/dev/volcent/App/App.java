package dev.volcent.App;

public class App {
    public static void main(String[] args) {

    }
}
